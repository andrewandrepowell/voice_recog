#include <stdio.h>
#include "xparameters.h"
#include "xspi.h"
#include "xtmrctr.h"

#include "FreeRTOS.h"
#include "task.h"
#include "portmacro.h"

#include "netif/xadapter.h"
#include "lwip/init.h"
#include "lwip/sockets.h"
#include "lwipopts.h"

#define NETWORK_EMAC_BASEADDR    ( XPAR_AXI_ETHERNETLITE_0_BASEADDR )
#define NETWORK_PORT             ( 7 )
#define NETWORK_BUFF_SIZE        ( 2048 )
#define NETWORK_CMD_READ         ( 0 )
#define NETWORK_CMD_WRITE        ( 1 )
#define THREAD_STACKSIZE         ( 1024 )
#define MIC3_DEVICE_ID           ( XPAR_AXI_QUAD_SPI_0_DEVICE_ID )
#define MIC3_BUFF_SIZE           ( 2 )
#define SAMPLE_TIMER_DEVICE_ID   ( XPAR_AXI_TIMER_1_DEVICE_ID )
#define SAMPLE_TIMER_DEFAULT     ( 0 )
#define SAMPLE_TIMER_HZ          ( XPAR_AXI_TIMER_1_CLOCK_FREQ_HZ )
//#define SAMPLE_TIMER_SAMPLE_RATE ( 44100 )
#define SAMPLE_TIMER_SAMPLE_RATE ( 1 )
#define SAMPLE_TIMER_COUNT       ( SAMPLE_TIMER_HZ / SAMPLE_TIMER_SAMPLE_RATE )
#define SAMPLE_TIMER_INT_ID      ( XPAR_INTC_0_TMRCTR_1_VEC_ID )


XSpi                                                                          mic3;
XTmrCtr                                                                       sample_timer;
volatile u8  __attribute__ ( ( aligned(0x100), section( ".buffer_block" ) ) ) send_buff[ NETWORK_BUFF_SIZE ];
volatile u8  __attribute__ ( ( aligned(0x100), section( ".buffer_block" ) ) ) recv_buff[ NETWORK_BUFF_SIZE ];
struct netif                                                                  server_netif;
struct netif*                                                                 echo_netif;

TaskHandle_t main_task_handle;

void mainTaskFunc( void* params );
void netTaskFunc( void* params );
void serviceThreadFunc( void* params );
void sampleTimerHandler( void* param, u8 TmrCtrNumber );
void print_ip( char *msg, ip_addr_t *ip );
void print_ip_settings( ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw );

int main( )
{

	/* Configure SPI Master for PmodMIC3. */
	configASSERT( XSpi_Initialize( &mic3, MIC3_DEVICE_ID )==XST_SUCCESS );
	configASSERT( XSpi_SetOptions( &mic3, XSP_MASTER_OPTION )==XST_SUCCESS );
	configASSERT( XSpi_Start( &mic3 )==XST_SUCCESS );
	XSpi_IntrGlobalDisable( &mic3 );

	/* Configure AXI Timer for sampling PmodMIC3. */
	configASSERT( XTmrCtr_Initialize( &sample_timer, SAMPLE_TIMER_DEVICE_ID )==XST_SUCCESS );
	configASSERT( XTmrCtr_SelfTest( &sample_timer, SAMPLE_TIMER_DEFAULT )==XST_SUCCESS );
	XTmrCtr_SetOptions( &sample_timer, SAMPLE_TIMER_DEFAULT, XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION | XTC_DOWN_COUNT_OPTION );
	XTmrCtr_SetResetValue( &sample_timer, SAMPLE_TIMER_DEFAULT, SAMPLE_TIMER_COUNT );
	XTmrCtr_SetHandler( &sample_timer, sampleTimerHandler, NULL );
	configASSERT( xPortInstallInterruptHandler( SAMPLE_TIMER_INT_ID, XTmrCtr_InterruptHandler, ( void* )&sample_timer )==pdPASS );
	vPortEnableInterrupt( SAMPLE_TIMER_INT_ID );
	XTmrCtr_Start( &sample_timer, SAMPLE_TIMER_DEFAULT );

	/* Start the main task. */
	configASSERT( xTaskCreate( mainTaskFunc, "mainTask", THREAD_STACKSIZE, NULL, DEFAULT_THREAD_PRIO, &main_task_handle )==pdPASS );

	/* Start FreeRTOS. */
	vTaskStartScheduler( );

	/* This point should never be reached. */
	while(1);
	return 0;
}

void sampleTimerHandler( void* param, u8 TmrCtrNumber )
{
	typedef union
	{
		u8 bytes[ MIC3_BUFF_SIZE ];
		u16 word;
	} Buf;
	Buf recvBuf;

	configASSERT( XSpi_SetSlaveSelect( &mic3, 1 )==XST_SUCCESS );
	configASSERT( XSpi_Transfer( &mic3, recvBuf.bytes, recvBuf.bytes, sizeof( Buf ) )==XST_SUCCESS );
	xil_printf( "Mic3 Data: %d\n\r", recvBuf.word );
}

void mainTaskFunc( void* params )
{
	lwip_init( );

	configASSERT( xTaskCreate( ( void ( * )( void* ) )netTaskFunc, "netTask", THREAD_STACKSIZE, NULL, DEFAULT_THREAD_PRIO, NULL )==pdPASS );

	while (1)
	{
		vTaskDelay( 2*configTICK_RATE_HZ );
	}

	vTaskDelete( NULL );
}

void netTaskFunc( void* params )
{
	{
		unsigned char mac_ethernet_address[ ] = { 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };
		ip_addr_t ipaddr, netmask, gw;

		xil_printf( "\r\n\r\n" );
		xil_printf( "----- Starting Server ------\r\n" );

		IP4_ADDR( &ipaddr,  192, 168, 1,   10 );
		IP4_ADDR( &netmask, 255, 255, 255, 0 );
		IP4_ADDR( &gw,      192, 168, 1,   1 );
		print_ip_settings( &ipaddr, &netmask, &gw );

		xil_printf( "Configuring the Ethernet MAC Lite as the designated MAC for lwIP.\r\n" );
		if ( !xemac_add( &server_netif, &ipaddr, &netmask, &gw, mac_ethernet_address, NETWORK_EMAC_BASEADDR ) )
		{
			xil_printf( "Error adding N/W interface\r\n" );
			return;
		}

		netif_set_default( &server_netif );
		netif_set_up( &server_netif );

		xil_printf( "Starting thread for reading from MAC.\n\r" );
		configASSERT( xTaskCreate( ( void ( * )( void* ) )xemacif_input_thread, "emacifInputThread", THREAD_STACKSIZE, NULL, DEFAULT_THREAD_PRIO, NULL )==pdPASS );
	}

	{
		int sock, new_sd;
		int size;

		struct sockaddr_in address, remote;

		xil_printf( "Creating server with socket API.\n\r" );
		memset(&address, 0, sizeof(address));

		if ( ( sock = lwip_socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
			return;

		address.sin_family      = AF_INET;
		address.sin_port        = htons( NETWORK_PORT );
		address.sin_addr.s_addr = INADDR_ANY;

		if ( lwip_bind( sock, (struct sockaddr *)&address, sizeof( address ) ) < 0 )
			return;

		lwip_listen( sock, 0 );
		size = sizeof(remote);

		while ( 1 )
		{
			if ( ( new_sd = lwip_accept( sock, ( struct sockaddr* )&remote, ( socklen_t *)&size ) ) > 0 )
			{
				xil_printf( "Creating thread to service client.\n\r" );
				configASSERT( xTaskCreate( ( void ( * )( void* ) )serviceThreadFunc, "serviceThread", THREAD_STACKSIZE, ( void* )new_sd, DEFAULT_THREAD_PRIO, NULL )==pdPASS );
			}
		}
	}

	vTaskDelete( NULL );
}

void serviceThreadFunc( void* params )
{
	typedef struct
	{
		u32 command;
		u32 addr;
		u32 raddr;
		u32 size;
	} Service;
	int          sd = ( int )params;
	volatile u8* curr_ptr;
	Service*     recv_cmd;
	Service      send_cmd;
	size_t       curr_size, sent_size;

	/* Receive service command. */
	curr_ptr  = recv_buff;
	curr_size = sizeof( Service );
	while ( curr_size!=0 )
	{
		sent_size  = read( sd, ( void* )curr_ptr, curr_size );
		curr_ptr  += sent_size;
		curr_size -= sent_size;
	}
	recv_cmd = ( Service* )recv_buff;

	/* Perform operation based on command. */
	if ( recv_cmd->command==NETWORK_CMD_READ )
	{
		/* Write out command. */
		send_cmd.command = NETWORK_CMD_WRITE;
		send_cmd.addr    = recv_cmd->raddr;
		send_cmd.raddr   = 0;
		send_cmd.size    = recv_cmd->size;

		curr_ptr  = ( volatile u8* )&send_cmd;
		curr_size = sizeof( Service );
		while ( curr_size!=0 )
		{
			sent_size  = write( sd, ( void* )curr_ptr, curr_size );
			curr_ptr  += sent_size;
			curr_size -= sent_size;
		}

		/* Write out the data. */
		curr_ptr  = ( volatile u8* )recv_cmd->addr;
		curr_size = recv_cmd->size;
		while ( curr_size!=0 )
		{
			sent_size  = write( sd, ( void* )curr_ptr, curr_size );
			curr_ptr  += sent_size;
			curr_size -= sent_size;
		}
	}

	close( sd );
	vTaskDelete( NULL );
}

void print_ip( char *msg, ip_addr_t *ip )
{
	xil_printf( msg );
	xil_printf( "%d.%d.%d.%d\n\r", ip4_addr1( ip ), ip4_addr2( ip ),
			ip4_addr3( ip ), ip4_addr4( ip ) );
}

void print_ip_settings( ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw )
{
	print_ip( "Board IP: ", ip );
	print_ip( "Netmask : ", mask );
	print_ip( "Gateway : ", gw );
}
