#include <stdio.h>
#include "xparameters.h"
#include "xspi.h"
#include "xtmrctr.h"

#include "FreeRTOS.h"
#include "task.h"
#include "portmacro.h"

#include "lwipopts.h"

#define THREAD_STACKSIZE         ( 1024 )
#define MIC3_DEVICE_ID           ( XPAR_AXI_QUAD_SPI_0_DEVICE_ID )
#define MIC3_BUFF_SIZE           ( 2 )
#define SAMPLE_TIMER_DEVICE_ID   ( XPAR_AXI_TIMER_1_DEVICE_ID )
#define SAMPLE_TIMER_DEFAULT     ( 0 )
#define SAMPLE_TIMER_HZ          ( XPAR_AXI_TIMER_1_CLOCK_FREQ_HZ )
//#define SAMPLE_TIMER_SAMPLE_RATE ( 44100 )
#define SAMPLE_TIMER_SAMPLE_RATE ( 1 )
#define SAMPLE_TIMER_COUNT       ( SAMPLE_TIMER_HZ / SAMPLE_TIMER_SAMPLE_RATE )
#define SAMPLE_TIMER_INT_ID      ( XPAR_INTC_0_TMRCTR_1_VEC_ID )


XSpi    mic3;
XTmrCtr sample_timer;

TaskHandle_t main_task_handle;

void mainTaskFunc( void* params );
void sampleTimerHandler( void* param, u8 TmrCtrNumber );

int main( )
{

	/* Configure SPI Master for PmodMIC3. */
	configASSERT( XSpi_Initialize( &mic3, MIC3_DEVICE_ID )==XST_SUCCESS );
	configASSERT( XSpi_SetOptions( &mic3, XSP_MASTER_OPTION )==XST_SUCCESS );
	configASSERT( XSpi_Start( &mic3 )==XST_SUCCESS );
	XSpi_IntrGlobalDisable( &mic3 );

	/* Configure AXI Timer for sampling PmodMIC3. */
	configASSERT( XTmrCtr_Initialize( &sample_timer, SAMPLE_TIMER_DEVICE_ID )==XST_SUCCESS );
	configASSERT( XTmrCtr_SelfTest( &sample_timer, SAMPLE_TIMER_DEFAULT )==XST_SUCCESS );
	XTmrCtr_SetOptions( &sample_timer, SAMPLE_TIMER_DEFAULT, XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION | XTC_DOWN_COUNT_OPTION );
	XTmrCtr_SetResetValue( &sample_timer, SAMPLE_TIMER_DEFAULT, SAMPLE_TIMER_COUNT );
	XTmrCtr_SetHandler( &sample_timer, sampleTimerHandler, NULL );
	configASSERT( xPortInstallInterruptHandler( SAMPLE_TIMER_INT_ID, XTmrCtr_InterruptHandler, ( void* )&sample_timer )==pdPASS );
	vPortEnableInterrupt( SAMPLE_TIMER_INT_ID );
	XTmrCtr_Start( &sample_timer, SAMPLE_TIMER_DEFAULT );

	/* Start the main task. */
	configASSERT( xTaskCreate( mainTaskFunc, "mainTask", THREAD_STACKSIZE, NULL, DEFAULT_THREAD_PRIO, &main_task_handle )==pdPASS );

	/* Start FreeRTOS. */
	vTaskStartScheduler( );

	/* This point should never be reached. */
	while(1);
	return 0;
}

void sampleTimerHandler( void* param, u8 TmrCtrNumber )
{
	typedef union
	{
		u8 bytes[ MIC3_BUFF_SIZE ];
		u16 word;
	} Buf;
	Buf recvBuf;

	configASSERT( XSpi_SetSlaveSelect( &mic3, 1 )==XST_SUCCESS );
	configASSERT( XSpi_Transfer( &mic3, recvBuf.bytes, recvBuf.bytes, sizeof( Buf ) )==XST_SUCCESS );
	xil_printf( "Mic3 Data: %d\n\r", recvBuf.word );
}

void mainTaskFunc( void* params )
{
	while (1)
	{

	}
}
